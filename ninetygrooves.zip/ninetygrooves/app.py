from flask import Flask, redirect, render_template
from datetime import datetime

app = Flask(__name__)

def get_current_year():
	return datetime.now().year

@app.route('/')
def home():
	current_year = datetime.now().year
	title = "NINETYGROOVES RECORDS - HOMEPAGE"
	description = "Utrecht Techno Record Label. Aimed at the 90s techno sound."
	keywords = "techno, label, 90s, old techno, label, record label, Utrecht, Nederland, Holland, The Netherlands, Dutch, Nederlands, Nederlandse, Utrechts, Nederland"
	return render_template('index.html', title=title, description=description, keywords=keywords, year=get_current_year())

@app.route('/releases')
def releases():
	current_year = datetime.now().year
	title = "NINETYGROOVES RECORDS - RELEASES"
	description = "List of official releases by NinetyGrooves Records."
	keywords = "techno, label, releases, label releases, 90s, old techno, label, record label, Utrecht, Nederland, Holland, The Netherlands, Dutch, Nederlands, Nederlandse, Utrechts, Nederland"
	return render_template('releases.html', title=title, description=description, keywords=keywords, year=get_current_year())

@app.route('/live')
def live():
	current_year = datetime.now().year
	title = "NINETYGROOVES RECORDS - LIVESTREAM HOMEPAGE"
	description = "The official livestream and VOD page from NinetyGrooves Records."
	keywords = "techno, label, releases, label releases, 90s, old techno, label, record label, Utrecht, Nederland, Holland, The Netherlands, Dutch, Nederlands, Nederlandse, Utrechts, Nederland"
	return render_template('livestream.html', title=title, description=description, keywords=keywords, year=get_current_year())

if __name__ == '__main__':
	app.run()